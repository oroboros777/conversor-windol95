CREATE DATABASE temperatura;

USE temperatura;

CREATE TABLE conversor (
	id	int primary key auto_increment,
    from_unit	varchar(25),
    to_unit		varchar(25),
    value		varchar(25)
);

insert into conversor (from_unit, to_unit, value)
values ('celsius', 'celsius', ' * 1)');

insert into conversor (from_unit, to_unit, value)
values ('celsius', 'fahrenheit', ' * 9/5) + 32');

insert into conversor (from_unit, to_unit, value)
values ('celsius', 'kelvin', ' + 273.15)');

insert into conversor (from_unit, to_unit, value)
values ('fahrenheit', 'fahrenheit', ' * 1)');

insert into conversor (from_unit, to_unit, value)
values ('fahrenheit', 'kelvin', ' - 32) * 5/9 + 273.15');

insert into conversor (from_unit, to_unit, value)
values ('fahrenheit', 'celsius', ' - 32) * 5/9');

insert into conversor (from_unit, to_unit, value)
values ('kelvin', 'kelvin', ' * 1)');

insert into conversor (from_unit, to_unit, value)
values ('kelvin', 'fahrenheit', ' - 273,15) * 9/5 + 32');

insert into conversor (from_unit, to_unit, value)
values ('kelvin', 'celsius', ' - 273,15)');