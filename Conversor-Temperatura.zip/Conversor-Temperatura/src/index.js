const express = require('express')
const cors = require('cors')
const mysql = require('mysql2')

const app = express()
const port = 3000

app.use(express.json())
app.use(cors())

const pool = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: 'Proz@2023',
    database: 'temperatura'
}).promise()

app.get('/:unit1/:unit2', async (req, res) => {
    const { unit1, unit2 } = req.params
    const [result] = await pool.query('SELECT value FROM conversor WHERE from_unit = ? AND to_unit = ?', [unit1, unit2])
    res.json(result)
})

app.listen(port, () => {
    console.log('App running')
})