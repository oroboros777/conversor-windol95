const from = document.getElementById('from')
const to = document.getElementById('to')
const value = document.getElementById('value')
const converter = document.getElementById('converter')
const resulth3 = document.getElementById('result')

converter.addEventListener('click', getValue)

async function getValue() {
    const response = await axios.get(`http://localhost:3000/${from.value}/${to.value}`)
    const result = response.data[0]
    resulth3.innerText = eval(`(${value.value}${result.value}`)
}